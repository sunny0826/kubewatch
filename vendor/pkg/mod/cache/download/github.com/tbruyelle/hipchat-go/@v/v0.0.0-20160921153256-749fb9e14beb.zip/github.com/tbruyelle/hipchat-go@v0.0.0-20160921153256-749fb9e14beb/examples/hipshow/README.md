hipshow
=====

Prints all rooms from your group

##### Usage

```bash
go build
./hipshow --token=<your auth token>
```
