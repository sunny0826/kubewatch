lol
=====

Prints the `(lol)` emoticon in the room in parameter.

##### Usage

```bash
go build
./hiplol --token=<your auth token> --room=<room id>
```
