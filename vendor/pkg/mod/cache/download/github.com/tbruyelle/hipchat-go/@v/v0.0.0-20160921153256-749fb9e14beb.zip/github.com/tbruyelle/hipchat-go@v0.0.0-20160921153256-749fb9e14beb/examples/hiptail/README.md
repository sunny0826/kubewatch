hiptail
=====

Prints recent messages in the room in parameter.

##### Usage

```bash
go build
./hiptail --token=<your auth token> --room=<room id>
```
